
function changeColor(){
    document.getElementById("first_header").style.color = "red";
}