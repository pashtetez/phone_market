(function () {
    'use strict'; 

    var app = angular
        .module('app',['ngRoute','ngAnimate'])
        .config(config)
        .controller('ModemController', ModemController);

//'ngRoute', 'ngCookies','ngResource','ngWebsocket','ngMaterial','scrollable-table','chart.js','dndLists', 'ngAnimate', 'ngSanitize', 'ngToast'])
app.controller('mainController', function($scope) {
    $scope.pageClass = 'page-home';
});

app.controller('aboutController', function($scope) {
    $scope.pageClass = 'page-about';
});

app.controller('contactController', function($scope) {
    $scope.pageClass = 'page-contact';
});

function searchTree(element){
     var r = [];
     r = r.concat(element['subitems']);
     console.log(element)
     if (element['subtiteles'].length){
          for(var i=0; i < element['subtiteles'].length; i++){
               r = r.concat(searchTree(element['subtiteles'][i]));
          }
     }
     return r;
}


        ModemController.$inject = ['$scope','$http' , '$rootScope','$window','$location','$timeout','$q','$route'];
        function ModemController($scope,$http, $rootScope,$window, $location,$timeout,$q,$route) {
                    $scope.pageClass = 'page-contact';
                    var fileName = "http://www.melt.com.ru/pdf/swap1.txt";
                                           $scope.records = [
                                               "Alfreds Futterkiste",
                                               "Berglunds snabbköp",
                                               "Centro comercial Moctezuma",
                                               "Ernst Handel",
                                           ]

                    $scope.records [0] = window.location.href;
                     $scope.upd = function(){

                        var docHeadObj = document.getElementsByTagName("head")[0];
                       var dynamicScript = document.createElement("script");
                       dynamicScript.type = "text/javascript";
                       dynamicScript.id="datascript"
                       if (window.location.href.indexOf('android_asset') == -1)
                            dynamicScript.src =  "my_live_loading_script.js";
                        else
                            dynamicScript.src =  "data.js?t="+new Date().getTime()+"data";
                           dynamicScript.onload = function(){
                           $scope.search = data['categories'][0]['group_code'];
                           if(!$scope.$$phase) {
                               $scope.$apply()
                           }
                       };
                       document.getElementById('datascript').remove();
                       docHeadObj.appendChild(dynamicScript);
                     };
                     $scope.upd();

                    $scope.items = function(){
                            return $scope.item
                    }

                     $scope.showitem = function(x){
                        if (x.hasOwnProperty('title'))
                            return x.title
                        else
                            return x["\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435"]
                     }
                     $scope.showimage = function(x){
                         if (x.hasOwnProperty('image'))
                             return x.image
                         else
                             return x["\u0424\u043e\u0442\u043e"]
                      }
                      $scope.okimage = function(x){
                               if (x.hasOwnProperty('image'))
                                   return x.image != '';
                               else
                                   return x["\u0424\u043e\u0442\u043e"] != 'http://www.melt.com.ru/images/noimage.jpg';
                            }


                    $scope.parent = [];
                    $scope.ready = true;
                    $scope.$on('$routeChangeSuccess', function($event, next, current) {
                        $timeout(function(){
                               $scope.pageClass = 'page-contact';
                               $scope.ready = true;
                         },300);
                     });


                    $scope.help = function(x){
                                    $scope.pageClass = 'page-about';
                                    $scope.xx = x;
                                    console.log($scope.xx);
                                    $timeout(function(){
                                        document.getElementById("changeitem").click();
                                    },10);
                       }

                     $scope.changeitem = function(){

                            if ($scope.ready){
                             var   x = $scope.xx ;
                             $scope.parent.push($scope.item);
                            if (x.hasOwnProperty('subtiteles') && x['subtiteles'].length)
                             $scope.item = x['subtiteles']
                             else if (x.hasOwnProperty('subitems') && x['subitems'].length)
                             $scope.item = x['subitems']
                             else
                             $scope.itemone = x
                            if(!$scope.$$phase) {
                            $scope.$apply()
                            }
                            $scope.ready = false;
                           $route.reload();
                           }
                     }
                     $scope.javaScriptCallAngular = function() {
                                if ($scope.parent.length !=0){
                     	            $scope.item = $scope.parent.pop();
                     	            $scope.itemone = null;
                                        if(!$scope.$$phase) {
                                        $scope.$apply()
                                        }
                                        $route.reload();
                                 }
                     	    };
                    $scope.itemone = null;
                    $scope.itemonelist = function(itemone) {
                        console.log(itemone);
                        if ($scope.itemone == null) return [];
//                        for(var i=0; i < itemone.keys; i++){
//                           console.log(itemone.children[i]);
//                        }
                        var keys = Object.keys(itemone);
                        keys.splice(keys.indexOf("$$hashKey"), 1);
                        keys.splice(keys.indexOf("empty_header"), 1);
                        console.log(keys);
                      return keys;
                    }

                    $scope.search='';
                    $scope.search=data['categories'][0]['group_code'];
                    $scope.item = const_data;
                    $scope.itemlist = searchTree({'subitems':[],'subtiteles':$scope.item});

                    $scope.searchfunc = function(item) {
                        if($scope.search.length <3)
                            return false;
//                        console.log(item);
//                        console.log(item["\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435"]);
                        if ((item["\u041a\u043e\u0434"].indexOf($scope.search) != -1) || (item["\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435"].toLowerCase().indexOf($scope.search.toLowerCase()) != -1) ){
                            return true;
                        }
                        return false;
                    };
                }

    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'index1.html',
                controllerAs: 'vm'
            })
            .when('/q', {
                templateUrl: 'index2.html',
                controllerAs: 'vm'
            });
    }
})();
