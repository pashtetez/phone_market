import json
import urllib.request
import shutil

with open('asd.txt',encoding='utf-8') as f:
    a = f.read()
    #a = a.split("\r\n")
    print("???")
