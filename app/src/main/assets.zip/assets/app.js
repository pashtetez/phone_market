(function () {
    'use strict'; 

    var app = angular
        .module('app',['ngRoute','ngAnimate'])
        .config(config)
        .controller('ModemController', ModemController);

//'ngRoute', 'ngCookies','ngResource','ngWebsocket','ngMaterial','scrollable-table','chart.js','dndLists', 'ngAnimate', 'ngSanitize', 'ngToast'])
app.controller('mainController', function($scope) {
    $scope.pageClass = 'page-home';
});

app.controller('aboutController', function($scope) {
    $scope.pageClass = 'page-about';
});

app.controller('contactController', function($scope) {
    $scope.pageClass = 'page-contact';
});


        ModemController.$inject = ['$scope','$http' , '$rootScope','$window','$location','$timeout','$q','$route'];
        function ModemController($scope,$http, $rootScope,$window, $location,$timeout,$q,$route) {
                    $scope.pageClass = 'page-contact';
                    var fileName = "http://www.melt.com.ru/pdf/swap1.txt";
                                           $scope.records = [
                                               "Alfreds Futterkiste",
                                               "Berglunds snabbköp",
                                               "Centro comercial Moctezuma",
                                               "Ernst Handel",
                                           ]

                    $scope.records [0] = window.location.href;
                     $scope.upd = function(){

                        var docHeadObj = document.getElementsByTagName("head")[0];
                       var dynamicScript = document.createElement("script");
                       dynamicScript.type = "text/javascript";
                       dynamicScript.id="datascript"
                       if (window.location.href.indexOf('android_asset') == -1)
                            dynamicScript.src =  "my_live_loading_script.js";
                        else
                            dynamicScript.src =  "data.js?t="+new Date().getTime()+"data";
                           dynamicScript.onload = function(){
                           $scope.records [0] = data['categories'][0]['group_code'];
                           if(!$scope.$$phase) {
                               $scope.$apply()
                           }
                       };
                       document.getElementById('datascript').remove();
                       docHeadObj.appendChild(dynamicScript);
                     };
                    // $scope.upd();

                    $scope.items = function(){
                            return $scope.item
                    }

                     $scope.showitem = function(x){
                        if (x.hasOwnProperty('title'))
                            return x.title
                        else
                            return x["\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435"]
                     }

                    $scope.parent = [];
                    $scope.ready = true;
                    $scope.$on('$routeChangeSuccess', function($event, next, current) {
                        $timeout(function(){
                               $scope.pageClass = 'page-contact';
                               $scope.ready = true;
                         },300);
                     });


                    $scope.help = function(x){
                                    $scope.pageClass = 'page-about';
                                    $scope.xx = x;
                                    console.log($scope.xx);
                                    $timeout(function(){
                                        document.getElementById("changeitem").click();
                                    },10);
                       }

                     $scope.changeitem = function(){
                            if ($scope.ready){
                             var   x = $scope.xx ;
                             $scope.parent.push($scope.item);
                            if (x['subtiteles'].length)
                             $scope.item = x['subtiteles']
                             else
                             $scope.item = x['subitems']
                            if(!$scope.$$phase) {
                            $scope.$apply()
                            }
                            $scope.ready = false;
                           $route.reload();
                           }
                     }
                     $scope.javaScriptCallAngular = function() {
                                if ($scope.parent.length !=0){
                     	            $scope.item = $scope.parent.pop();
                     	            if(!$scope.$$phase) {
                                    $scope.$apply()
                                    }
                                    $route.reload();
                                 }
                     	    };
                    $scope.item = const_data;

                }

    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'index1.html',
                controllerAs: 'vm'
            })
            .when('/q', {
                templateUrl: 'index2.html',
                controllerAs: 'vm'
            });
    }
})();
